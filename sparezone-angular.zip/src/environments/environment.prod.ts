export const environment = {
  production: true,
  base_url:'http://54.218.66.217/sparezone/'
};
