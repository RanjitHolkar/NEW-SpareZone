import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminInvoiceRoutingModule } from './admin-invoice-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdminInvoiceRoutingModule
  ]
})
export class AdminInvoiceModule { }
