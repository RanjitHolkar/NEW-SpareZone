import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-setting',
  templateUrl: './nav-setting.component.html',
  styleUrls: ['./nav-setting.component.css']
})
export class NavSettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
