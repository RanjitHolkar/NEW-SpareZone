import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-mgmt',
  templateUrl: './api-mgmt.component.html',
  styleUrls: ['./api-mgmt.component.css']
})
export class ApiMgmtComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
