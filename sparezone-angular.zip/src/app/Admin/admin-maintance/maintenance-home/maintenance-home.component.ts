import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintenance-home',
  templateUrl: './maintenance-home.component.html',
  styleUrls: ['./maintenance-home.component.css']
})
export class MaintenanceHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
