import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EditVehicleService {

  constructor() { }
}
