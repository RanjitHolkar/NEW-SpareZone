import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-feedback',
  templateUrl: './reports-feedback.component.html',
  styleUrls: ['./reports-feedback.component.css']
})
export class ReportsFeedbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
