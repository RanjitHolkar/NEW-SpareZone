import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capricon-members',
  templateUrl: './capricon-members.component.html',
  styleUrls: ['./capricon-members.component.css']
})
export class CapriconMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
