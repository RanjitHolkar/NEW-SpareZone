import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-background-images',
  templateUrl: './background-images.component.html',
  styleUrls: ['./background-images.component.css']
})
export class BackgroundImagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
