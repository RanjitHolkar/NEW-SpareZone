import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicle-add',
  templateUrl: './vehicle-add.component.html',
  styleUrls: ['./vehicle-add.component.css']
})
export class VehicleAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
