import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supplier-dash',
  templateUrl: './supplier-dash.component.html',
  styleUrls: ['./supplier-dash.component.css']
})
export class SupplierDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
